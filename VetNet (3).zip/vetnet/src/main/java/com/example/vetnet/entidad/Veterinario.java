package com.example.vetnet.entidad;

public class Veterinario {
    
}
